package Game;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class OneHandGame extends JFrame {
    List<Card> removedCards = new ArrayList<>();

    private Deck deck;
    private Hand hand;
    private int score;
    private int jokerCount;
    public int nbOfCards;
    private String state;

    private JLabel[] cardLabels;
    private JButton drawButton;
    private JButton jokerButton;
    private JLabel scoreLabel;
    private JLabel cardsTotal;
    private JLabel stateOfTheGame;

    public OneHandGame() {
        setTitle("One Hand Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = (int) (screenSize.width * 0.8);
        int height = (int) (screenSize.height * 0.8);
        setSize(width, height);
        setLocationRelativeTo(null);

        JLabel background = new JLabel(new ImageIcon("img/background.png"));
        background.setLayout(new BorderLayout());

        deck = new Deck();
        hand = new Hand(deck);
        score = 0;
        jokerCount = 3;

        setupUI(background);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                updateComponentSizes();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OneHandGame().setVisible(true));
    }

    private void setupUI(JLabel background) {
        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel headerPanel = new JPanel(new BorderLayout());

        cardsTotal = new JLabel("Discarded cards: " + nbOfCards, SwingConstants.LEFT);
        cardsTotal.setHorizontalAlignment(SwingConstants.LEFT);
        cardsTotal.setFont(new Font("Rockwell", Font.BOLD, (int) (getHeight() * 0.05)));
        cardsTotal.setBorder(BorderFactory.createEmptyBorder(10, 200, 0, 0));
        headerPanel.add(cardsTotal, BorderLayout.WEST);

        scoreLabel = new JLabel("Score: " + score, SwingConstants.RIGHT);
        scoreLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        scoreLabel.setFont(new Font("Rockwell", Font.BOLD, (int) (getHeight() * 0.05)));
        scoreLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 200));
        headerPanel.add(scoreLabel, BorderLayout.EAST);

        JPanel cardPanel = new JPanel(new GridLayout(1, 4));
        cardLabels = new JLabel[4];
        for (int i = 0; i < 4; i++) {
            cardLabels[i] = new JLabel(new ImageIcon(hand.getCard(i).getImagePath()));
            cardPanel.add(cardLabels[i]);
        }

        JPanel bottomPanel = new JPanel(new BorderLayout());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        drawButton = new JButton("Draw");
        drawButton.addActionListener(this::drawCard);
        buttonPanel.add(drawButton);

        jokerButton = new JButton("Joker (" + jokerCount + ")");
        jokerButton.addActionListener(this::useJoker);
        buttonPanel.add(jokerButton);

        bottomPanel.add(buttonPanel, BorderLayout.CENTER);

        JPanel statePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        statePanel.setOpaque(false);
        stateOfTheGame = new JLabel("Previous state : " + state);
        stateOfTheGame.setFont(new Font("Rockwell", Font.BOLD, (int) (getHeight() * 0.045)));
        stateOfTheGame.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        statePanel.add(stateOfTheGame);
        bottomPanel.add(statePanel, BorderLayout.LINE_START);

        mainPanel.setOpaque(false);
        cardPanel.setOpaque(false);
        buttonPanel.setOpaque(false);
        headerPanel.setOpaque(false);
        bottomPanel.setOpaque(false);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(cardPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        background.add(mainPanel);
        setContentPane(background);
    }

    private void drawCard(ActionEvent e) {
        Card keepCard1 = hand.getCard(0);
        Card keepCard2 = hand.getCard(1);
        Card keepCard3 = hand.getCard(2);
        Card keepCard4 = hand.getCard(3);
        if (deck.getSize() == 0 && keepCard1.getRank() != keepCard4.getRank() && keepCard1.getSuit().compareTo(keepCard4.getSuit()) != 0 ) {
            if(removedCards.size() <= 1 || jokerCount ==0)
            {
                JOptionPane.showMessageDialog(this, "Your score is : "+ score , "Game Over", JOptionPane.INFORMATION_MESSAGE);
                return;
            }else{
            JOptionPane.showMessageDialog(this, "No more cards in the deck!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            return;}
        }




        if (keepCard1.getRank() == keepCard4.getRank()) {
            score += 5;
            nbOfCards += 4;
            state = "Same rank! You threw 4 cards!";

            switch (removedCards.size()){
                case 0 :
                    hand = new Hand(deck);
                    break;
                case 1 :
                    hand.replaceCard(0, deck.drawCard());
                    hand.replaceCard(1, deck.drawCard());
                    hand.replaceCard(2, deck.drawCard());
                    hand.replaceCard(3, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    break;
                case 2 :
                    hand.replaceCard(0, deck.drawCard());
                    hand.replaceCard(1, deck.drawCard());
                    hand.replaceCard(2, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    hand.replaceCard(3, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    break;
                case 3 :
                    hand.replaceCard(0, deck.drawCard());
                    hand.replaceCard(1, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    hand.replaceCard(2, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    hand.replaceCard(3, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    break;
                default:
                    hand.replaceCard(0, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    hand.replaceCard(1, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    hand.replaceCard(2, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
                    hand.replaceCard(3, removedCards.getLast());
                    removedCards.remove(removedCards.getLast());
            }
        } else if (keepCard1.getSuit().equals(keepCard4.getSuit())) {
            score += 2;
            nbOfCards += 2;
            state = "Same suit! You threw your 2 middle cards!";
            if (removedCards.isEmpty()) {
                hand.replaceCard(0, deck.drawCard());
                hand.replaceCard(1, deck.drawCard());
                hand.replaceCard(2, keepCard1);
            } else if (removedCards.size() == 1) {
                hand.replaceCard(0, deck.drawCard());
                hand.replaceCard(1, keepCard1);
                hand.replaceCard(2, keepCard4);
                hand.replaceCard(3, removedCards.getLast());
                removedCards.remove(removedCards.getLast());
            } else {
                hand.replaceCard(1, keepCard4);
                hand.replaceCard(2, removedCards.getLast());
                removedCards.remove(removedCards.getLast());
                hand.replaceCard(3, removedCards.getLast());
                removedCards.remove(removedCards.getLast());
            }
        } else {
            removedCards.add(keepCard4);
            state = "Nothing special... Keep going";
            System.out.println("----------------------\nContent of the hidden cards:");
            for (Card cards : removedCards) {
                System.out.println(cards.toString());
            }


            hand.replaceCard(0, deck.drawCard());
            hand.replaceCard(1, keepCard1);
            hand.replaceCard(2, keepCard2);
            hand.replaceCard(3, keepCard3);
        }

        stateOfTheGame.setText("Previous state : " + state);
        updateUI();
        updateComponentSizes();
    }

    private void useJoker(ActionEvent e) {
        if (jokerCount <= 0) {
            JOptionPane.showMessageDialog(this, "No more jokers left!", "Joker Limit Reached", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Card keepCard1 = hand.getCard(0);
        Card keepCard2 = hand.getCard(1);
        Card keepCard3 = hand.getCard(2);
        Card keepCard4 = hand.getCard(3);

        if (keepCard1.getRank() == keepCard4.getRank() || keepCard1.getSuit().equals(keepCard4.getSuit())) {
            JOptionPane.showMessageDialog(this, "You can't use the joker in this case.", "Invalid Move", JOptionPane.INFORMATION_MESSAGE);
        } else if(deck.getSize() > 0) {
            jokerCount--;
            hand.replaceCard(0, deck.drawCard());
            hand.replaceCard(1, deck.drawCard());
            hand.replaceCard(2, keepCard1);
        }
        else
        {
            jokerCount--;
            hand.replaceCard(1, keepCard4);
            hand.replaceCard(2, removedCards.getLast());
            removedCards.remove(removedCards.getLast());
            hand.replaceCard(3, removedCards.getLast());
            removedCards.remove(removedCards.getLast());
        }

        updateUI();
        updateComponentSizes();
    }

    private void updateUI() {
        for (int i = 0; i < 4; i++) {
            if (hand.getCard(i) != null) {
                cardLabels[i].setIcon(new ImageIcon(hand.getCard(i).getImagePath()));
            } else {
                cardLabels[i].setIcon(null);
            }
        }
        scoreLabel.setText("Score: " + score);
        cardsTotal.setText("Discarded cards: " + nbOfCards);
        jokerButton.setText("Joker (" + jokerCount + ")");

        repaint();
    }

    private void updateComponentSizes() {
        scoreLabel.setFont(new Font("Rockwell", Font.BOLD, (int) (getHeight() * 0.05)));

        for (int i = 0; i < 4; i++) {
            if (cardLabels[i] != null) {
                ImageIcon cardIcon = new ImageIcon(hand.getCard(i).getImagePath());
                Image scaledImage = cardIcon.getImage().getScaledInstance((int) (getWidth() * 0.15), (int) (getHeight() * 0.35), Image.SCALE_SMOOTH);
                cardLabels[i].setIcon(new ImageIcon(scaledImage));
            }
        }

        drawButton.setFont(new Font("Rockwell", Font.BOLD, (int) (getHeight() * 0.04)));
        jokerButton.setFont(new Font("Rockwell", Font.BOLD, (int) (getHeight() * 0.04)));
    }
}
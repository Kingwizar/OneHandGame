package Game;

import java.util.*;

public class Deck {
    private List<Card> cards;

    public Deck() {
        cards = new ArrayList<>();
        loadDeck();
        shuffleDeck();
    }

    private void loadDeck() {
        String[] suits = {"hearts", "diamonds", "clubs", "spades"};
        for (String suit : suits) {
            for (int i = 1; i <= 13; i++) {
                cards.add(new Card(suit, i, "img/" + suit + i + ".png"));
            }
        }
    }

    private void shuffleDeck() {
        Collections.shuffle(cards, new Random(System.nanoTime()));
    }

    public Card drawCard() {
        if (!cards.isEmpty()) {
            Random random = new Random();
            int randomIndex = random.nextInt(cards.size());
            Card drawnCard = cards.remove(randomIndex);
            return drawnCard;
        } else {
            return null;
        }
    }


    public int getSize() {
        return cards.size();
    }
}

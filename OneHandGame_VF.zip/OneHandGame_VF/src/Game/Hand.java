package Game;

import java.util.*;

public class Hand extends Deck{
    private List<Card> cards;

    public Hand(Deck deck) {
        cards = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            cards.add(deck.drawCard());
        }
    }

    public void replaceCard(int index, Card card) {
            cards.set(index, card);
    }

    public Card getCard(int index) {
        if (index >= 0 && index < cards.size()) {
            return cards.get(index);
        } else {
            return null;
        }
    }

    public List<Card> getCards() {
        return cards;
    }
}

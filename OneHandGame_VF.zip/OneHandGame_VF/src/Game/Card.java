package Game;

public class Card {
    private String suit;
    private int rank;
    private String imagePath;

    public Card(String suit, int rank, String imagePath) {
        this.suit = suit;
        this.rank = rank;
        this.imagePath = imagePath;
    }

    public String getSuit() {
        return suit;
    }

    public int getRank() {
        return rank;
    }

    public String getImagePath() {
        return imagePath;
    }

    @Override
    public String toString() {
        String rankName;
        switch (rank) {
            case 1:
                rankName = "Ace";
                break;
            case 11:
                rankName = "Jack";
                break;
            case 12:
                rankName = "Queen";
                break;
            case 13:
                rankName = "King";
                break;
            default:
                rankName = String.valueOf(rank);
                break;
        }
        return rankName + " of " + suit;
    }
}
